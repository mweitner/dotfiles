# Visual Studio Code

# Install

We installed VS code (vscode) as snap first.

Prototype is ubuntu (server, i3):

```javascript
sudo snap install --classic code
```

However, with update to 1.9… code crashes on start…

Verify version:

```none
~$ code -v
1.90.0
89de5a8d4d6205e5b11647eb6a74844ca23d2573
x64
```

Solution fix crashes:

* <https://github.com/microsoft/vscode/issues/204159>

> # Solution
>
> * I uninstalled the snap version
>
> ```none
> $ snap remove code
> ```
>
> * Downloaded <https://update.code.visualstudio.com/1.89.1/linux-deb-x64/stable>
> * then run
>
>   ```none
>   $ sudo dpkg -i code_1.89.1-1715060508_amd64.deb
>   ```
>
>    and it is now working again.

I installed the exact same version `code_1.89.1-1715060508_amd64.deb` and it worked.

# Documentation

Apart from google, there is the vscode documentation:

* <https://code.visualstudio.com/docs/getstarted/settings>


# Configure

It's quit easy to install so called Extensions through `File/Preferances/Extensions` . For example for a C/C++ project it suggest to install appropriate C/C++ extensions automatically.

After installing following extensions and opening a c project folder the main.c file was easy compiled and run:

* CppTools (default c/c++ extension for c and c++ programming):
  * <https://marketplace.visualstudio.com/items?itemName=ms-vscode.cpptools-extension-pack>
  * <https://code.visualstudio.com/docs/cpp/cpp-ide>
* Code Runner:
  * <https://marketplace.visualstudio.com/items?itemName=formulahendry.code-runner>
  * make sure Code Runner Extension is set to run program at terminal
* Vim (vscodevim):
  * <https://github.com/VSCodeVim/Vim>

# Code Formatter

vscode or let's say the cpptools extension uses clang-formatter as default code formatting tool and fallback is the Microsoft Visual Studio code style.

## clang-format

vscode looks at root of workspace for a `.clang-format` file.

The clang toolchain provides good documentation regarding clang-format:

* <https://clang.llvm.org/docs/ClangFormat.html>

There is a nice web based configurator to generate `.clang-format` file:

* <https://zed0.co.uk/clang-format-configurator/>

After saving from web tool as the `google` style default:

* move it to project

```javascript
$ cp ~/Downloads/clang-format.txt ~/dev/prog-interview-exposed/.clang-format
```

```bash
$ cat .clang-format
---
BasedOnStyle: Google

...
```

As we see the .clang-format file contains currently only the `BasedOnStyle` attribute pointing to google.

Personally especially with C++, I like two adaptations based on googles default:

* NamespaceIndentation (default: none, adaptation: all)
* ColumnLimit (default: no limit, adaptation: 120)

# How to C project

Hello world tutorial in context of a linux host:

* <https://code.visualstudio.com/docs/cpp/config-linux>

Here I use explicitly C which should be valid for c++ as well.

## Build

the config file `vscode/task.json` contains task declarations like `build` task to build my program using gcc compiler.

## Debug

the config file `vscode/launch.json` contains configurations used e.g. to launch gdb debugging session.

* create initial empty launch.json file by `Run/Add Configuration`
* open launch.json file and select `` Run/Add Configuration/C/C++ (gdb) launch`  ``which creates launch config entry
* change program, cwd attributes and add preLaunchTask and miDebuggerPath attributtes

```javascript
"configurations": [
        {
            "name": "(gdb) Launch",
            "type": "cppdbg",
            "request": "launch",
            "program": "${fileDirname}/${fileBasenameNoExtension}",
            "args": [],
            "stopAtEntry": false,
            "cwd": "${workspaceFolder}",
            "environment": [],
            "externalConsole": false,
            "MIMode": "gdb",
            "setupCommands": [
                {
                    "description": "Enable pretty-printing for gdb",
                    "text": "-enable-pretty-printing",
                    "ignoreFailures": true
                },
                {
                    "description":  "Set Disassembly Flavor to Intel",
                    "text": "-gdb-set disassembly-flavor intel",
                    "ignoreFailures": true
                }
            ],
            "preLaunchTask": "C/C++: gcc build active file",
            "miDebuggerPath": "/usr/bin/gdb"
        }

    ]
```

Start debugging by F5 or `Run/Start Debugging `

# How to use vim

There is a vim extension available:

* <https://marketplace.visualstudio.com/items?itemName=vscodevim.vim>

# How to large projects

<https://code.visualstudio.com/docs/setup/linux#_visual-studio-code-is-unable-to-watch-for-file-changes-in-this-large-workspace-error-enospc>

Exclude files/folders from file watcher!